from setuptools import setup
import os
from glob import glob

package_name = 'diff'

setup(
    name=package_name,
    version='0.0.0',
    packages=[],
    py_modules=[],
    data_files=[
        # Install launch, urdf, rviz, and mesh files
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*.rviz')),
        (os.path.join('share', package_name, 'meshes'), glob('meshes/*')),
        (os.path.join('share', package_name, 'scripts'), glob('scripts/*')),
        (os.path.join('share', package_name), ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ashy',
    maintainer_email='ashishshajan480@gmail.com',
    description='ROS 2 simulation package for Husky robot using Gazebo and RViz',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Example: 'script_name = scripts.script_name:main',
        ],
    },
)

