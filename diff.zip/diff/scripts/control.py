#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import tty
import termios
import select
import threading

class KeyboardControlNode(Node):
    def __init__(self):
        super().__init__('keyboard_control_node')
        
        # Create publisher for cmd_vel
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Parameters for velocity
        self.linear_speed = 0.5  # m/s
        self.angular_speed = 1.0  # rad/s
        
        # Initialize message
        self.twist_msg = Twist()
        
        # Initialize termios
        self.settings = termios.tcgetattr(sys.stdin)
        
        # Print control instructions
        self.print_instructions()
        
        # Start keyboard input thread
        self.running = True
        self.input_thread = threading.Thread(target=self.get_key)
        self.input_thread.daemon = True
        self.input_thread.start()

    def print_instructions(self):
        self.get_logger().info('Keyboard Controller Started')
        self.get_logger().info('---------------------------')
        self.get_logger().info('Use the following keys to control the robot:')
        self.get_logger().info('w: Forward')
        self.get_logger().info('s: Backward')
        self.get_logger().info('a: Turn Left')
        self.get_logger().info('d: Turn Right')
        self.get_logger().info('q: Increase linear speed')
        self.get_logger().info('z: Decrease linear speed')
        self.get_logger().info('e: Increase angular speed')
        self.get_logger().info('c: Decrease angular speed')
        self.get_logger().info('x: Stop')
        self.get_logger().info('CTRL+C to quit')
        self.get_logger().info('Current linear speed: {} m/s'.format(self.linear_speed))
        self.get_logger().info('Current angular speed: {} rad/s'.format(self.angular_speed))
    
    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        
        while self.running:
            rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
            if rlist:
                key = sys.stdin.read(1)
                self.process_key(key)
        
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
    
    def process_key(self, key):
        if key == 'w':
            # Move forward
            self.twist_msg.linear.x = self.linear_speed
            self.twist_msg.angular.z = 0.0
        elif key == 's':
            # Move backward
            self.twist_msg.linear.x = -self.linear_speed
            self.twist_msg.angular.z = 0.0
        elif key == 'a':
            # Turn left
            self.twist_msg.linear.x = 0.0
            self.twist_msg.angular.z = self.angular_speed
        elif key == 'd':
            # Turn right
            self.twist_msg.linear.x = 0.0
            self.twist_msg.angular.z = -self.angular_speed
        elif key == 'q':
            # Increase linear speed
            self.linear_speed += 0.1
            self.get_logger().info('Linear speed: {} m/s'.format(self.linear_speed))
        elif key == 'z':
            # Decrease linear speed
            self.linear_speed = max(0.1, self.linear_speed - 0.1)
            self.get_logger().info('Linear speed: {} m/s'.format(self.linear_speed))
        elif key == 'e':
            # Increase angular speed
            self.angular_speed += 0.1
            self.get_logger().info('Angular speed: {} rad/s'.format(self.angular_speed))
        elif key == 'c':
            # Decrease angular speed
            self.angular_speed = max(0.1, self.angular_speed - 0.1)
            self.get_logger().info('Angular speed: {} rad/s'.format(self.angular_speed))
        elif key == 'x':
            # Stop
            self.twist_msg.linear.x = 0.0
            self.twist_msg.angular.z = 0.0
        elif key == '\x03':  # CTRL+C
            self.get_logger().info('Shutting down')
            self.running = False
            self.twist_msg.linear.x = 0.0
            self.twist_msg.angular.z = 0.0
            self.publisher_.publish(self.twist_msg)
            rclpy.shutdown()
            return
        
        # Publish the command
        self.publisher_.publish(self.twist_msg)
    
    def __del__(self):
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = KeyboardControlNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the robot before shutting down
        stop_msg = Twist()
        node.publisher_.publish(stop_msg)
        node.running = False
        node.get_logger().info('Node shutting down')
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
