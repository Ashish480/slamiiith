import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import TextSubstitution, EnvironmentVariable
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable, TimerAction
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
import launch.conditions

def generate_launch_description():
    # Get package directories
    pkg_diff = get_package_share_directory('diff')
    pkg_worldmodels = get_package_share_directory('my_sim_tesi_gazebo')

    # Launch configurations
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    world_file = LaunchConfiguration('world_file', default='room.sdf')
    x_pose = LaunchConfiguration('x', default='0.0')
    y_pose = LaunchConfiguration('y', default='0.0')
    z_pose = LaunchConfiguration('z', default='0.2')
    yaw_pose = LaunchConfiguration('yaw', default='0.0')
    use_rviz = LaunchConfiguration('use_rviz', default='true')
    use_joint_gui = LaunchConfiguration('use_joint_gui', default='false')
    use_ros2_control = LaunchConfiguration('use_ros2_control', default='false')
    robot_prefix = LaunchConfiguration('robot_prefix', default='')
    robot_name = LaunchConfiguration('robot_name', default='p3dx')

    # Declare launch arguments
    declare_use_sim_time = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true'
    )

    declare_world_file = DeclareLaunchArgument(
        'world_file',
        default_value='room.sdf',
        description='Specify world file name (inside worlds/)'
    )

    declare_x = DeclareLaunchArgument(
        'x',
        default_value='0.0',
        description='x position'
    )

    declare_y = DeclareLaunchArgument(
        'y',
        default_value='0.0',
        description='y position'
    )

    declare_z = DeclareLaunchArgument(
        'z',
        default_value='0.2',
        description='z position'
    )

    declare_yaw = DeclareLaunchArgument(
        'yaw',
        default_value='0.0',
        description='yaw orientation'
    )

    declare_use_rviz = DeclareLaunchArgument(
        'use_rviz',
        default_value='true',
        description='Whether to launch RViz'
    )

    declare_use_joint_gui = DeclareLaunchArgument(
        'use_joint_gui',
        default_value='false',
        description='Whether to launch Joint State Publisher GUI'
    )

    declare_use_ros2_control = DeclareLaunchArgument(
        'use_ros2_control',
        default_value='false',
        description='Use ros2_control instead of Gazebo diff drive plugin'
    )

    declare_robot_prefix = DeclareLaunchArgument(
        'robot_prefix',
        default_value='',
        description='Robot link prefix (e.g., robot1_). Leave empty for no prefix'
    )

    declare_robot_name = DeclareLaunchArgument(
        'robot_name',
        default_value='p3dx',
        description='Robot name in Gazebo simulation'
    )

    # Set IGN_GAZEBO_RESOURCE_PATH so Ignition can find custom models
    set_ign_resource_path = SetEnvironmentVariable(
        name='IGN_GAZEBO_RESOURCE_PATH',
        value=[
            PathJoinSubstitution([pkg_worldmodels, 'models']),
            TextSubstitution(text=':'),
            EnvironmentVariable('IGN_GAZEBO_RESOURCE_PATH', default_value='')
        ]
    )

    # Robot description with proper parameter passing
    xacro_file = os.path.join(pkg_diff, 'urdf', 'robot.urdf.xacro')
    robot_description = ParameterValue(
        Command([
            'xacro ', xacro_file,
            ' prefix:=', robot_prefix,
            ' use_ros2_control:=', use_ros2_control,
            ' sim_mode:=true'
        ]), 
        value_type=str
    )

    # Launch Ignition Gazebo with dynamic world file
    ignition_gazebo = ExecuteProcess(
        cmd=[
            'ign', 'gazebo', '-r', '-v', '4',
            PathJoinSubstitution([pkg_worldmodels, 'worlds', world_file])
        ],
        output='screen'
    )

    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'robot_description': robot_description,
            'publish_frequency': 30.0,
            'frame_prefix': '',  # Add this to ensure correct frame naming
            'ignore_timestamp': True  # Add this to help with old data issues
        }]
    )

    # Joint State Publisher (when NOT using ros2_control AND NOT using GUI)
    joint_state_publisher = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'use_gui': False,
            'rate': 30
        }]
        # Remove conditions for now - we'll control this with TimerAction
    )

    # Joint State Publisher GUI node (conditional)
    joint_state_publisher_gui = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'rate': 30
        }],
        condition=launch.conditions.IfCondition(use_joint_gui)
    )
     
    # Controller Manager (only when using ros2_control)
    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        name='controller_manager',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time}
        ],
        condition=launch.conditions.IfCondition(use_ros2_control)
    )

    # Spawn controllers (only when using ros2_control)
    spawn_joint_state_broadcaster = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'joint_state_broadcaster'],
        output='screen',
        condition=launch.conditions.IfCondition(use_ros2_control)
    )

    spawn_diff_drive_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'diff_drive_controller'],
        output='screen',
        condition=launch.conditions.IfCondition(use_ros2_control)
    )

    # Delayed controller spawning
    delayed_controller_spawn = TimerAction(
        period=3.0,
        actions=[spawn_joint_state_broadcaster, spawn_diff_drive_controller],
        condition=launch.conditions.IfCondition(use_ros2_control)
    )

    # Enhanced Bridge node with sensor messages
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='bridge',
        output='screen',
        parameters=[{
            'qos_overrides./tf_static.publisher.durability': 'transient_local',
            'qos_overrides./clock.publisher.reliability': 'reliable',  # Add this
            'qos_overrides./clock.publisher.history_depth': 100,       # Add this
            'use_sim_time': use_sim_time
        }],
        arguments=[
            # Basic robot topics
            '/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry@gz.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState@gz.msgs.Model',
            '/tf@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V',
            '/tf_static@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V',
            '/clock@rosgraph_msgs/msg/Clock@gz.msgs.Clock',
            
            
            # Sensor topics
            '/scan@sensor_msgs/msg/LaserScan@gz.msgs.LaserScan',
            '/camera/image_raw@sensor_msgs/msg/Image@gz.msgs.Image',
            '/camera/camera_info@sensor_msgs/msg/CameraInfo@gz.msgs.CameraInfo',
            
            # Additional sensor topics (if needed)
            '/imu@sensor_msgs/msg/Imu@gz.msgs.IMU',
            '/sonar@sensor_msgs/msg/Range@gz.msgs.SonarStamped'
        ],
        remappings=[
            ('/tf', '/tf'),  # Ensure tf topic is correctly mapped
            ('/tf_static', '/tf_static')  # Ensure static tf topic is correctly mapped
        ]

    )

    # Spawn robot node
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        name='spawn_diff',
        output='screen',
        arguments=[
            '-name', robot_name,
            '-topic', 'robot_description',
            '-x', x_pose,
            '-y', y_pose,
            '-z', z_pose,
            '-Y', yaw_pose,
            '-allow_renaming', 'true'
        ]
    )

    # RViz node
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time
        }],
        condition=launch.conditions.IfCondition(use_rviz)
    )

    # Delayed joint state publisher (only when NOT using ros2_control and NOT using GUI)
    delayed_joint_state_publisher = TimerAction(
        period=1.0,
        actions=[joint_state_publisher],
        condition=launch.conditions.UnlessCondition(use_ros2_control)
    )

    # Delayed RViz launch
    delayed_rviz = TimerAction(
        period=2.0,
        actions=[rviz_node],
        condition=launch.conditions.IfCondition(use_rviz)
    )

    return LaunchDescription([
        # Declare all arguments
        declare_use_sim_time,
        declare_world_file,
        declare_x,
        declare_y,
        declare_z,
        declare_yaw,
        declare_use_rviz,
        declare_use_joint_gui,
        declare_use_ros2_control,
        declare_robot_prefix,
        declare_robot_name,
        
        # Set environment
        set_ign_resource_path,
        
        # Launch simulation first
        ignition_gazebo,
        
        # Robot description and state
        robot_state_publisher,
        
        # Bridge and spawning
        bridge,
        spawn_robot,
        
        # Joint state publishers
        joint_state_publisher_gui,  # This will only run if use_joint_gui is true
        delayed_joint_state_publisher,  # This will run if NOT using ros2_control
        
        # ros2_control components (conditional)
        controller_manager,
        delayed_controller_spawn,
        
        # Delayed RViz launch (commented out the immediate rviz_node)
        delayed_rviz,
    ])