 ros2 launch slam_toolbox online_async_launch.py slam_params_file:=./src/diff/config/mapper_params_online_async.yaml 

ros2 launch nav2_bringup navigation_launch.py 
